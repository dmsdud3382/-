insert into dm.qualt_check_status (
  degree, 
  fid_no, 
  fid_nm, 
  table_id, 
  table_name, 
  column_id, 
  column_name, 
  char_value_01, 
  num_value_01, 
  load_date
)

select *
from (
  select 
    4 as degree, 
    '2-FID-NDQ-006' as fid_no, 
    '자료형식 - 날짜(문자형)' as fid_nm, 
    ':TABLE_ID' as table_id, 
    ':TABLE_NAME' as table_name, 
    ':COLUMN_ID' as column_id, 
    ':COLUMN_NAME' as column_name, 
    translate(
      ":COLUMN_ID", 
      '0123456789', 
      '9999999999'
    ) as char_value_01, 
    count(*) as num_value_01
  from ":TABLE_ID"
  group by translate(
    ":COLUMN_ID", 
    '0123456789', 
    '9999999999'
  )
) x
union all 
select *
from (
  select 
    4 as degree, 
    '2-FID-NDQ-006' as fid_no, 
    '자료형식 - 날짜(문자형)' as fid_nm, 
    ':TABLE_ID' as table_id, 
    ':TABLE_NAME' as table_name, 
    ':COLUMN_ID' as column_id, 
    ':COLUMN_NAME' as column_name, 
    translate(
      ":COLUMN_ID", 
      '0123456789', 
      '9999999999'
    ) as char_value_01, 
    count(*) as num_value_01
  from ":TABLE_ID"
  group by translate(
    ":COLUMN_ID", 
    '0123456789', 
    '9999999999'
  )
) x;

