create table dm.qualt_check_status(
  degree numeric null,
  fid_no text(20) null,
  fid_nm text(100) null,
  table_id text(100) null,
  table_name text(100) null,
  column_id text(100) null,
  column_name text(100) null,
  char_value_01 text(100) null,
  char_value_02 text(100) null,
  num_value_01 numeric null,
  num_value_02 numeric null,
  load_date datetime null
);

