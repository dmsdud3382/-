drop table dm.qualt_check_status;

