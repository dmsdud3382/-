create table dm.qualt_check_status(
  degree numeric,
  fid_no varchar(20),
  fid_nm varchar(100),
  table_id varchar(100),
  table_name varchar(100),
  column_id varchar(100),
  column_name varchar(100),
  char_value_01 varchar(100),
  char_value_02 varchar(100),
  num_value_01 numeric,
  num_value_02 numeric,
  load_date timestamp
);

