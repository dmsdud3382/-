create table dm.qualt_check_status(
  degree numeric null,
  fid_no lvarchar(20) null,
  fid_nm lvarchar(100) null,
  table_id lvarchar(100) null,
  table_name lvarchar(100) null,
  column_id lvarchar(100) null,
  column_name lvarchar(100) null,
  char_value_01 lvarchar(100) null,
  char_value_02 lvarchar(100) null,
  num_value_01 numeric null,
  num_value_02 numeric null,
  load_date datetime null
);

