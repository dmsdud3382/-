insert into dm.qualt_check_status (
  degree, 
  fid_no, 
  fid_nm, 
  table_id, 
  table_name, 
  char_value_01, 
  char_value_02, 
  num_value_01, 
  num_value_02, 
  load_date
)
select 
  4 degree, 
  '2-FID-NDQ-008' fid_no, 
  '날짜범위 유효성' fid_nm, 
  ':TABLE_ID' table_id, 
  ':TABLE_NAME' table_name, 
  ':COLUMN_ID(시작일)' char_value_01, 
  ':COLUMN_ID(종료일)' char_value_02, 
  count(case
    when valid_pd_begin_dy > valid_pd_end_dy then '1'
  end) num_value_01, 
  count(*) num_value_02, 
  current
from :TABLE_ID
where (
  1 = 1
  and :COLUMN_ID(시작일) is not null
  and :COLUMN_ID(종료일) is not null
)
union all 
select 
  4 degree, 
  '2-FID-NDQ-008' fid_no, 
  '범위 유효성 - 날짜' fid_nm, 
  ':TABLE_ID' table_id, 
  ':TABLE_NAME' table_name, 
  ':COLUMN_ID(시작일)' char_value_01, 
  ':COLUMN_ID(종료일)' char_value_02, 
  count(case
    when valid_pd_begin_dy > valid_pd_end_dy then '1'
  end) num_value_01, 
  count(*) num_value_02, 
  current
from :TABLE_ID
where (
  1 = 1
  and :COLUMN_ID(시작일) is not null
  and :COLUMN_ID(종료일) is not null
);

