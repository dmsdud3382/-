create table dm.qualt_check_status(
  degree number null,
  fid_no varchar2(20) null,
  fid_nm varchar2(100) null,
  table_id varchar2(100) null,
  table_name varchar2(100) null,
  column_id varchar2(100) null,
  column_name varchar2(100) null,
  char_value_01 varchar2(100) null,
  char_value_02 varchar2(100) null,
  num_value_01 number null,
  num_value_02 number null,
  load_date timestamp null
);

