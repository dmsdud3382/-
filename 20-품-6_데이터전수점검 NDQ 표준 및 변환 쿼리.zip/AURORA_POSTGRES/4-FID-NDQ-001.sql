insert into dm.qualt_check_status (
  degree, 
  fid_no, 
  fid_nm, 
  table_id, 
  table_name, 
  column_id, 
  column_name, 
  char_value_01, 
  num_value_01, 
  load_date
)
select 
  4 as degree, 
  '2-FID-NDQ-001' as fid_no, 
  '코드(허용범위 분석) - 여부' as fid_nm, 
  ':TABLE_ID' as table_id, 
  ':TABLE_NAME' as table_name, 
  ':COLUMN_ID' as column_id, 
  ':COLUMN_NAME' as column_name, 
  :COLUMN_ID as char_value_01, 
  count(*) as num_value_01, 
  current_timestamp
from :TABLE_ID
group by :COLUMN_ID
union all 
select 
  4 as degree, 
  '2-FID-NDQ-001' as fid_no, 
  '코드(허용범위 분석) - 여부' as fid_nm, 
  ':TABLE_ID' as table_id, 
  ':TABLE_NAME' as table_name, 
  ':COLUMN_ID' as column_id, 
  ':COLUMN_NAME' as column_name, 
  :COLUMN_ID as char_value_01, 
  count(*) as num_value_01, 
  current_timestamp
from :TABLE_ID
group by :COLUMN_ID;

