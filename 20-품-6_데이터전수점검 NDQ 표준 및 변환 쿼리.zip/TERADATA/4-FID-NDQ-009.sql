insert into dm.qualt_check_status (
  degree, 
  fid_no, 
  fid_nm, 
  table_id, 
  table_name, 
  num_value_01, 
  load_date
)

select *
from (
  select 
    4 degree, 
    '2-FID-NDQ-009' fid_no, 
    '테이블 적재 건수 통계 점검' fid_nm, 
    ':TABLE_ID' table_id, 
    ':TABLE_NAME' table_name, 
    count(*) num_value_01, 
    current_timestamp
  from :TABLE_ID
) x
union all 
select *
from (
  select 
    4 degree, 
    '2-FID-NDQ-009' fid_no, 
    '테이블 적재 건수 통계 점검' fid_nm, 
    ':TABLE_ID' table_id, 
    ':TABLE_NAME' table_name, 
    count(*) num_value_01, 
    current_timestamp
  from :TABLE_ID
) x;

