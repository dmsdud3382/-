insert into dm.qualt_check_status (
  degree, 
  fid_no, 
  fid_nm, 
  table_id, 
  table_name, 
  column_id, 
  column_name, 
  num_value_01, 
  num_value_02, 
  load_date
)
select 
  t.*
from (
  select 
    4 as degree, 
    '2-FID-NDQ-007' as fid_no, 
    '완전성 - Not Null 컬럼' as fid_nm, 
    ':TABLE_ID' as table_id, 
    ':TABLE_NAME' as table_name, 
    ':COLUMN_ID' as column_id, 
    ':COLUMN_NAME' as column_name, 
    count(case
      when (
        trim(:COLUMN_ID) = ''
        or trim(:COLUMN_ID) is null
      ) then '1'
    end) as num_value_01, 
    count(*) as num_value_02, 
    current_timestamp()
  from :TABLE_ID
  union all 
  select 
    4 as degree, 
    '2-FID-NDQ-007' as fid_no, 
    '완전성 - Not Null 컬럼' as fid_nm, 
    ':TABLE_ID' as table_id, 
    ':TABLE_NAME' as table_name, 
    ':COLUMN_ID' as column_id, 
    ':COLUMN_NAME' as column_name, 
    count(case
      when (
        trim(:COLUMN_ID) = ''
        or trim(:COLUMN_ID) is null
      ) then '1'
    end) as num_value_01, 
    count(*) as num_value_02, 
    current_timestamp()
  from :TABLE_ID
) t;

