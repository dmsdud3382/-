create table dm.qualt_check_status(
  degree numeric null,
  fid_no string(20) null,
  fid_nm string(100) null,
  table_id string(100) null,
  table_name string(100) null,
  column_id string(100) null,
  column_name string(100) null,
  char_value_01 string(100) null,
  char_value_02 string(100) null,
  num_value_01 numeric null,
  num_value_02 numeric null,
  load_date timestamp null
);

