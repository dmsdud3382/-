create table dm.qualt_check_status(
  degree decimal null,
  fid_no varchar(20) null,
  fid_nm varchar(100) null,
  table_id varchar(100) null,
  table_name varchar(100) null,
  column_id varchar(100) null,
  column_name varchar(100) null,
  char_value_01 varchar(100) null,
  char_value_02 varchar(100) null,
  num_value_01 decimal null,
  num_value_02 decimal null,
  load_date timestamp null
);

