insert into dm.qualt_check_status (
  degree, 
  fid_no, 
  fid_nm, 
  table_id, 
  table_name, 
  column_id, 
  column_name, 
  char_value_01, 
  num_value_01, 
  load_date
)
select 
  4 degree, 
  '2-FID-NDQ-001' fid_no, 
  '코드(허용범위 분석) - 여부' fid_nm, 
  ':TABLE_ID' table_id, 
  ':TABLE_NAME' table_name, 
  ':COLUMN_ID' column_id, 
  ':COLUMN_NAME' column_name, 
  :COLUMN_ID char_value_01, 
  count(*) num_value_01, 
  current_timestamp
from :TABLE_ID
group by :COLUMN_ID
union all 
select 
  4 degree, 
  '2-FID-NDQ-001' fid_no, 
  '코드(허용범위 분석) - 여부' fid_nm, 
  ':TABLE_ID' table_id, 
  ':TABLE_NAME' table_name, 
  ':COLUMN_ID' column_id, 
  ':COLUMN_NAME' column_name, 
  :COLUMN_ID char_value_01, 
  count(*) num_value_01, 
  current_timestamp
from :TABLE_ID
group by :COLUMN_ID;

