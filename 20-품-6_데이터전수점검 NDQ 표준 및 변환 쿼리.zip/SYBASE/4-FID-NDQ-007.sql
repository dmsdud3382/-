insert into dm.qualt_check_status (
  degree, 
  fid_no, 
  fid_nm, 
  table_id, 
  table_name, 
  column_id, 
  column_name, 
  num_value_01, 
  num_value_02, 
  load_date
)
select 
  4 degree, 
  '2-FID-NDQ-007' fid_no, 
  '완전성 - Not Null 컬럼' fid_nm, 
  ':TABLE_ID' table_id, 
  ':TABLE_NAME' table_name, 
  ':COLUMN_ID' column_id, 
  ':COLUMN_NAME' column_name, 
  count(case
    when (
      trim(:COLUMN_ID) = ''
      or trim(:COLUMN_ID) is null
    ) then '1'
  end) num_value_01, 
  count(*) num_value_02, 
  current timestamp
from :TABLE_ID
union all 
select 
  4 degree, 
  '2-FID-NDQ-007' fid_no, 
  '완전성 - Not Null 컬럼' fid_nm, 
  ':TABLE_ID' table_id, 
  ':TABLE_NAME' table_name, 
  ':COLUMN_ID' column_id, 
  ':COLUMN_NAME' column_name, 
  count(case
    when (
      trim(:COLUMN_ID) = ''
      or trim(:COLUMN_ID) is null
    ) then '1'
  end) num_value_01, 
  count(*) num_value_02, 
  current timestamp
from :TABLE_ID;

