
CREATE FUNCTION `translate` (
    tar VARCHAR (255),
    ori VARCHAR (255),
    rpl VARCHAR (255)
) RETURNS VARCHAR (255) CHARSET utf8mb4 DETERMINISTIC BEGIN

    DECLARE i INT UNSIGNED DEFAULT 0;
    DECLARE cur_char CHAR (1);
    DECLARE ori_idx INT UNSIGNED;
    DECLARE result VARCHAR (255);

    SET result = '';

    WHILE i <= length(tar) DO
        SET cur_char = mid(tar, i, 1);
        SET ori_idx = INSTR(ori, cur_char);
        SET result = concat(
            result,
            REPLACE(
                cur_char,
                mid(ori, ori_idx, 1),
                mid(rpl, ori_idx, 1)
        ));
        SET i = i + 1;
    END WHILE;
    RETURN result;
END
